package com.fazil.payment.config;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.fazil.payment.cache.CacheInvalidationSubscriber;
import com.fazil.payment.token.CachedToken;

/**
 * Central cache configuration — Caffeine L1 (primary) + Redis L2 + pub/sub invalidation.
 *
 * ┌──────────────────────────────────────────────────────────────────┐
 * │  Read path (every request):                                      │
 * │    Caffeine L1  →  0.01ms, in-process, zero network             │
 * │    Redis L2     →  1–3ms, network, only on Caffeine MISS        │
 * │    OAuth fetch  →  100–500ms, only when both caches cold        │
 * │                                                                  │
 * │  Write path (on token refresh):                                  │
 * │    1. Write Caffeine L1                                          │
 * │    2. Write Redis L2 (cross-instance warm-up source)            │
 * │    3. Publish invalidation event → all instances clear L1       │
 * │                                                                  │
 * │  Why Caffeine L1 for OAuth tokens:                               │
 * │    Token value is IDENTICAL across all instances within TTL.    │
 * │    No inconsistency risk from a per-instance copy.               │
 * │    High-throughput services avoid a Redis network hop per req.   │
 * │                                                                  │
 * │  Use Redis L1 instead for: merchant config, routing rules,      │
 * │  feature flags — anything where stale local copy causes harm.   │
 * └──────────────────────────────────────────────────────────────────┘
 */
@Configuration
@EnableCaching
public class CacheConfig {

    // ── Constants — single source of truth ────────────────────────────────────
    public static final String OAUTH_TOKEN_CACHE    = "oauth-tokens";
    public static final String INVALIDATION_CHANNEL = "cache:invalidation";
    public static final String REDIS_KEY_PREFIX     = "payment-gateway::";

    // ── Caffeine L1 CacheManager — @Primary (default for all @Cacheable) ──────
    /**
     * @Primary: every @Cacheable annotation resolves to this by default.
     * Each named cache has its own TTL and max size.
     * recordStats() feeds cache hit/miss metrics into Micrometer automatically.
     */
    @Bean("caffeineCacheManager")
    @Primary
    public CacheManager caffeineCacheManager(TokenCacheProperties props) {
        CaffeineCacheManager manager = new CaffeineCacheManager();

        manager.registerCustomCache(OAUTH_TOKEN_CACHE,
                Caffeine.newBuilder()
                        .expireAfterWrite(props.caffeineTtlMinutes(), TimeUnit.MINUTES)
                        .maximumSize(props.maxCaffeineSize())
                        .recordStats()
                        .build());

        // ── Future caches — add here, each with independent TTL ────────────────
        // manager.registerCustomCache("merchant-config",
        //         Caffeine.newBuilder().expireAfterWrite(60, TimeUnit.MINUTES)
        //                 .maximumSize(500).recordStats().build());
        //
        // manager.registerCustomCache("payment-routes",
        //         Caffeine.newBuilder().expireAfterWrite(10, TimeUnit.MINUTES)
        //                 .maximumSize(100).recordStats().build());

        return manager;
    }

    // ── Redis L2 CacheManager — consulted only on Caffeine miss ───────────────
    /**
     * Used as a cross-instance warm-up source:
     *   - When a new pod starts cold, it reads from Redis L2 instead of
     *     calling the OAuth server. Redis holds the token written by an
     *     existing healthy instance.
     *   - Serialization: JSON so tokens are readable in redis-cli and
     *     survive rolling deploys safely.
     */
    @Bean("redisCacheManager")
    public CacheManager redisCacheManager(
            RedisConnectionFactory factory,
            TokenCacheProperties props) {

        RedisCacheConfiguration defaultConfig = RedisCacheConfiguration
                .defaultCacheConfig()
                .prefixCacheNameWith(REDIS_KEY_PREFIX)
                .disableCachingNullValues()
                .serializeKeysWith(
                        RedisSerializationContext.SerializationPair
                                .fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(
                        RedisSerializationContext.SerializationPair
                                .fromSerializer(new GenericJackson2JsonRedisSerializer()));

        // Per-cache TTL override
        RedisCacheConfiguration oauthConfig = defaultConfig
                .entryTtl(Duration.ofMinutes(props.redisTtlMinutes()));

        return RedisCacheManager.builder(factory)
                .cacheDefaults(defaultConfig)
                .withCacheConfiguration(OAUTH_TOKEN_CACHE, oauthConfig)
                .build();
    }

    // ── Raw typed Caffeine bean — programmatic access ─────────────────────────
    /**
     * Same underlying cache as caffeineCacheManager["oauth-tokens"] but
     * exposed as a typed bean to avoid casting and enable:
     *   1. isExpiredOrExpiringSoon() proactive refresh buffer check.
     *   2. Direct invalidation from the pub/sub subscriber.
     *   3. Snapshot reads for HealthIndicator / diagnostics.
     */
    @Bean("oauthTokenLocalCache")
    public Cache<String, CachedToken> oauthTokenLocalCache(TokenCacheProperties props) {
        return Caffeine.newBuilder()
                .expireAfterWrite(props.caffeineTtlMinutes(), TimeUnit.MINUTES)
                .maximumSize(props.maxCaffeineSize())
                .recordStats()
                .build();
    }

    // ── Redis pub/sub invalidation listener ───────────────────────────────────
    /**
     * All instances subscribe to "cache:invalidation".
     * When any instance rotates credentials or evicts a token, it publishes
     * a message here → every other instance immediately clears its Caffeine L1.
     *
     * Message format: "<cacheName>:<key>"
     *   "oauth-tokens:provider::gateway"   → evict one entry
     *   "oauth-tokens:*"                   → evict all entries in cache
     */
    @Bean
    public RedisMessageListenerContainer cacheInvalidationContainer(
            RedisConnectionFactory factory,
            CacheInvalidationSubscriber subscriber) {

        RedisMessageListenerContainer container = new RedisMessageListenerContainer();
        container.setConnectionFactory(factory);
        container.addMessageListener(
                new MessageListenerAdapter(subscriber, "onInvalidationMessage"),
                new ChannelTopic(INVALIDATION_CHANNEL));
        return container;
    }

    // ── Redisson distributed lock ─────────────────────────────────────────────
    /**
     * Used only during the Redis L2 refresh path.
     * Prevents thundering herd when all instances have cold Caffeine L1
     * simultaneously (e.g. full restart or post-eviction).
     * Only one instance fetches a new token; others wait and read from Redis L2.
     */
    @Bean("oauthTokenRefreshLock")
    public RLock oauthTokenRefreshLock(RedissonClient redisson) {
        return redisson.getLock("oauth:token:refresh:lock");
    }

    // ── RestClient for OAuth token endpoint ───────────────────────────────────
    @Bean("oauthRestClient")
    public RestClient oauthRestClient(OAuthProviderProperties props) {
        var factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout((int) props.connectTimeout().toMillis());
        factory.setReadTimeout((int) props.readTimeout().toMillis());
        return RestClient.builder()
                .baseUrl(props.tokenUrl())
                .requestFactory(factory)
                .build();
    }
}
