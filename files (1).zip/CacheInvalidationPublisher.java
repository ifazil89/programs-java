package com.fazil.payment.cache;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import com.fazil.payment.config.CacheConfig;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Publishes cache invalidation events to the Redis pub/sub channel.
 *
 * All running instances subscribe to this channel (via CacheInvalidationSubscriber)
 * and immediately clear their local Caffeine L1 entry when a message arrives.
 *
 * Usage:
 *   publisher.invalidate(CacheConfig.OAUTH_TOKEN_CACHE, "provider::gateway");
 *   publisher.invalidateAll(CacheConfig.OAUTH_TOKEN_CACHE);
 *
 * Message format on the wire: "<cacheName>:<key>"
 *   e.g. "oauth-tokens:provider::gateway"
 *        "oauth-tokens:*"  (wildcard — subscriber evicts entire cache)
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CacheInvalidationPublisher {

    private final StringRedisTemplate redis;

    /**
     * Invalidates a single cache entry across all instances.
     *
     * @param cacheName the named cache (e.g. "oauth-tokens")
     * @param key       the cache key (e.g. "provider::gateway")
     */
    public void invalidate(String cacheName, String key) {
        String message = cacheName + ":" + key;
        publish(message);
        log.info("Cache invalidation published: channel={} message={}",
                CacheConfig.INVALIDATION_CHANNEL, message);
    }

    /**
     * Invalidates ALL entries in a named cache across all instances.
     * Use after credential rotation or emergency token revoke.
     *
     * @param cacheName the named cache to fully clear
     */
    public void invalidateAll(String cacheName) {
        String message = cacheName + ":*";
        publish(message);
        log.warn("Full cache invalidation published: channel={} cacheName={}",
                CacheConfig.INVALIDATION_CHANNEL, cacheName);
    }

    private void publish(String message) {
        try {
            redis.convertAndSend(CacheConfig.INVALIDATION_CHANNEL, message);
        } catch (Exception e) {
            // Non-fatal: Redis pub/sub failure does not break the token flow.
            // Caffeine TTL will expire naturally — worst case, stale token
            // for at most caffeineTtlMinutes after a credential rotation.
            log.warn("Cache invalidation publish failed (non-fatal): {}", e.getMessage());
        }
    }
}
