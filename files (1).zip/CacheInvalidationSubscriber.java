package com.fazil.payment.cache;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Component;

import com.fazil.payment.config.CacheConfig;
import com.fazil.payment.token.CachedToken;

import lombok.extern.slf4j.Slf4j;

/**
 * Receives cache invalidation events from the Redis pub/sub channel
 * and clears the local Caffeine L1 cache on THIS instance.
 *
 * Every running instance subscribes to "cache:invalidation".
 * When any instance publishes an invalidation (e.g. after credential rotation),
 * ALL instances — including the publisher — receive this message and
 * clear their local entry.
 *
 * Message format: "<cacheName>:<key>"
 *   "oauth-tokens:provider::gateway"  → evict single entry
 *   "oauth-tokens:*"                  → evict all entries in cache
 *
 * The method name "onInvalidationMessage" is referenced in CacheConfig's
 * MessageListenerAdapter — it must match exactly.
 */
@Slf4j
@Component
public class CacheInvalidationSubscriber {

    private final com.github.benmanes.caffeine.cache.Cache<String, CachedToken> caffeineCache;

    public CacheInvalidationSubscriber(
            @Qualifier("oauthTokenLocalCache")
            com.github.benmanes.caffeine.cache.Cache<String, CachedToken> caffeineCache) {
        this.caffeineCache = caffeineCache;
    }

    /**
     * Called by Spring's MessageListenerAdapter when a message arrives.
     * Method name must match the delegate method name in CacheConfig.
     *
     * @param message raw Redis message body
     */
    public void onInvalidationMessage(String message) {
        if (message == null || message.isBlank()) {
            log.warn("Received blank invalidation message — ignoring");
            return;
        }

        // Format: "<cacheName>:<key>"
        int separatorIdx = message.indexOf(':');
        if (separatorIdx < 0) {
            log.warn("Malformed invalidation message: '{}' — ignoring", message);
            return;
        }

        String cacheName = message.substring(0, separatorIdx);
        String key       = message.substring(separatorIdx + 1);

        // Only handle caches we own
        if (!CacheConfig.OAUTH_TOKEN_CACHE.equals(cacheName)) {
            log.debug("Ignoring invalidation for unknown cache: {}", cacheName);
            return;
        }

        if ("*".equals(key)) {
            caffeineCache.invalidateAll();
            log.info("Caffeine L1 fully invalidated via pub/sub: cacheName={}", cacheName);
        } else {
            caffeineCache.invalidate(key);
            log.info("Caffeine L1 entry invalidated via pub/sub: cacheName={} key={}", cacheName, key);
        }
    }
}
