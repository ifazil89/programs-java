package com.fazil.payment.cache;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import org.redisson.api.RLock;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import com.github.benmanes.caffeine.cache.Cache;
import com.fazil.payment.config.CacheConfig;
import com.fazil.payment.config.TokenCacheProperties;
import com.fazil.payment.token.CachedToken;
import com.fazil.payment.token.OAuthTokenFetcher;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import lombok.extern.slf4j.Slf4j;

/**
 * OAuth token cache service — Caffeine L1 (primary) → Redis L2 → OAuth fetch.
 *
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │  getToken() call flow                                               │
 * │                                                                     │
 * │  Layer 1 — Caffeine L1 (@Cacheable, caffeineCacheManager)          │
 * │    Hit  → return immediately (0.01ms, zero network)                │
 * │    Miss → Layer 2                                                   │
 * │                                                                     │
 * │  Layer 2 — Redis L2 (circuit-broken, explicit read)                │
 * │    Hit  → populate Caffeine L1 → return (1–3ms)                   │
 * │    Miss → Layer 3                                                   │
 * │    DOWN → skip to Layer 3 (circuit breaker trips after 3 failures) │
 * │                                                                     │
 * │  Layer 3 — OAuth server fetch                                       │
 * │    Distributed lock (Redis UP) → one instance fetches              │
 * │    Local ReentrantLock (Redis DOWN) → one thread fetches           │
 * │    → write Caffeine L1 + Redis L2 + publish invalidation event     │
 * └─────────────────────────────────────────────────────────────────────┘
 *
 * @Cacheable role:
 *   Placed on the Caffeine read method (L1 hit path).
 *   caffeineCacheManager is @Primary so no explicit cacheManager needed.
 *   The annotation covers the fast path — resilience logic wraps it for L2/L3.
 *
 * Threading:
 *   Hot path (L1 hit): fully lock-free.
 *   Refresh path: ReentrantLock — virtual-thread safe, no carrier pinning.
 *   Multi-instance thundering herd: Redisson distributed lock on Redis path.
 */
@Slf4j
@Service
public class OAuthTokenCacheService {

    // ── Cache key ─────────────────────────────────────────────────────────────
    // Namespaced: "provider::<name>" makes it trivial to add per-provider keys later.
    // In Caffeine : "provider::gateway"
    // In Redis    : "payment-gateway::oauth-tokens::provider::gateway"
    static final String TOKEN_CACHE_KEY = "provider::gateway";

    private static final String REDIS_CB_NAME = "redis-oauth";

    private final OAuthTokenFetcher                fetcher;
    private final Cache<String, CachedToken>       caffeineCache;
    private final CacheManager                     redisCacheManager;
    private final CacheInvalidationPublisher       invalidationPublisher;
    private final RLock                            distributedLock;
    private final CircuitBreaker                   redisCb;
    private final TokenCacheProperties             cacheProps;

    /** Local lock — used ONLY when Redis is completely unreachable */
    private final ReentrantLock localRefreshLock = new ReentrantLock();

    public OAuthTokenCacheService(
            OAuthTokenFetcher fetcher,
            @Qualifier("oauthTokenLocalCache") Cache<String, CachedToken> caffeineCache,
            @Qualifier("redisCacheManager")    CacheManager redisCacheManager,
            CacheInvalidationPublisher         invalidationPublisher,
            @Qualifier("oauthTokenRefreshLock") RLock distributedLock,
            CircuitBreakerRegistry             cbRegistry,
            TokenCacheProperties               cacheProps) {

        this.fetcher               = fetcher;
        this.caffeineCache         = caffeineCache;
        this.redisCacheManager     = redisCacheManager;
        this.invalidationPublisher = invalidationPublisher;
        this.distributedLock       = distributedLock;
        this.redisCb               = cbRegistry.circuitBreaker(REDIS_CB_NAME);
        this.cacheProps            = cacheProps;

        attachCircuitBreakerLogging();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Returns a valid Bearer token. Never returns null.
     * All caching, fallback, and refresh logic is transparent to callers.
     */
    public String getToken() {

        // ── Layer 1: Caffeine L1 via @Cacheable ───────────────────────────────
        // getFromCaffeineCache() is annotated @Cacheable(caffeineCacheManager).
        // On hit: returns immediately without any network call.
        // On miss: body returns null → we fall through to Redis L2.
        CachedToken local = getFromCaffeineCache();
        if (local != null && !local.isExpiredOrExpiringSoon(cacheProps.refreshBufferMinutes())) {
            log.debug("L1 HIT — Caffeine, remaining={}", local.remainingValidity());
            return local.accessToken();
        }

        if (local != null) {
            log.debug("L1 token expiring soon — refreshing proactively");
        }

        // ── Layer 2: Redis L2 (circuit-broken) ───────────────────────────────
        try {
            CachedToken redisToken = redisCb.executeCallable(this::readFromRedis);

            if (redisToken != null && !redisToken.isExpiredOrExpiringSoon(cacheProps.refreshBufferMinutes())) {
                log.debug("L2 HIT — Redis, remaining={}", redisToken.remainingValidity());
                // Populate Caffeine L1 so subsequent requests on this instance are fast
                caffeineCache.put(TOKEN_CACHE_KEY, redisToken);
                return redisToken.accessToken();
            }

            // Redis up but empty or token expiring → refresh with distributed lock
            log.debug("L2 MISS — Redis empty or expiring, acquiring distributed lock");
            return refreshViaDistributedLock();

        } catch (CallNotPermittedException e) {
            log.warn("Redis CB OPEN [{}] — skipping L2, going to OAuth fetch", redisCb.getState());
        } catch (Exception e) {
            log.warn("Redis L2 error [{}]: {} — skipping to OAuth fetch",
                    e.getClass().getSimpleName(), e.getMessage());
        }

        // ── Layer 3: Direct OAuth fetch (Redis fully unavailable) ─────────────
        log.info("L1+L2 unavailable — fetching directly from OAuth server");
        return refreshWithLocalLock();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // @CACHEABLE — Caffeine L1 read (hot path)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * @Cacheable on caffeineCacheManager (the @Primary CacheManager).
     *
     * On CACHE HIT  : Spring intercepts the call, returns cached CachedToken directly.
     *                 Method body never executes. Zero overhead.
     * On CACHE MISS : Method body executes, returns null.
     *                 unless = "#result == null" prevents null from being stored.
     *                 Caller proceeds to Redis L2.
     *
     * Package-private: only called by getToken() — not part of the public API.
     */
    @Cacheable(
            value  = CacheConfig.OAUTH_TOKEN_CACHE,
            key    = "'" + TOKEN_CACHE_KEY + "'",
            unless = "#result == null"
    )
    CachedToken getFromCaffeineCache() {
        // Body executes only on cache miss — returns null to signal a miss.
        // Actual token storage into Caffeine is done programmatically via
        // caffeineCache.put() after a successful Redis L2 read or OAuth fetch.
        log.debug("L1 MISS — Caffeine cache cold for key={}", TOKEN_CACHE_KEY);
        return null;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // CACHE EVICTION
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Evicts single token entry from Caffeine L1, Redis L2, and all other
     * instances via pub/sub invalidation.
     *
     * Call after: OAuth credential rotation, forced token revoke.
     *
     * @CacheEvict clears Caffeine L1 (the @Primary CacheManager).
     * Redis L2 and other instances are cleared via the invalidation publisher.
     */
    @CacheEvict(
            value = CacheConfig.OAUTH_TOKEN_CACHE,
            key   = "'" + TOKEN_CACHE_KEY + "'"
    )
    public void evictToken() {
        log.warn("Token evicted from Caffeine L1");
        evictFromRedis(TOKEN_CACHE_KEY);
        invalidationPublisher.invalidate(CacheConfig.OAUTH_TOKEN_CACHE, TOKEN_CACHE_KEY);
        log.warn("Token invalidation published to all instances");
    }

    /**
     * Evicts ALL token entries from Caffeine L1, Redis L2, and all instances.
     * Use for emergency full revoke.
     */
    @CacheEvict(
            value      = CacheConfig.OAUTH_TOKEN_CACHE,
            allEntries = true
    )
    public void evictAllTokens() {
        log.warn("All tokens evicted from Caffeine L1");
        evictAllFromRedis();
        invalidationPublisher.invalidateAll(CacheConfig.OAUTH_TOKEN_CACHE);
        log.warn("Full cache invalidation published to all instances");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PRIVATE: REDIS L2 READ
    // ══════════════════════════════════════════════════════════════════════════

    private CachedToken readFromRedis() {
        org.springframework.cache.Cache redisCache =
                redisCacheManager.getCache(CacheConfig.OAUTH_TOKEN_CACHE);
        if (redisCache == null) return null;

        org.springframework.cache.Cache.ValueWrapper wrapper =
                redisCache.get(TOKEN_CACHE_KEY);
        return wrapper != null ? (CachedToken) wrapper.get() : null;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PRIVATE: REFRESH PATHS
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Refresh path when Redis is reachable.
     * Redisson distributed lock: only ONE instance across the cluster fetches.
     * All others wait → double-check Redis after lock → reuse if already written.
     */
    private String refreshViaDistributedLock() throws Exception {
        boolean locked = distributedLock.tryLock(5, 10, TimeUnit.SECONDS);
        try {
            // Double-check: another instance may have refreshed while we waited
            CachedToken rechecked = readFromRedis();
            if (rechecked != null && !rechecked.isExpiredOrExpiringSoon(cacheProps.refreshBufferMinutes())) {
                log.debug("Token found in Redis L2 after acquiring lock (another instance refreshed)");
                caffeineCache.put(TOKEN_CACHE_KEY, rechecked);
                return rechecked.accessToken();
            }

            // We are the winner — fetch and write all layers
            CachedToken fresh = fetcher.fetch();
            writeBothLayers(fresh);
            return fresh.accessToken();

        } finally {
            if (locked) distributedLock.unlock();
        }
    }

    /**
     * Refresh path when Redis is completely unavailable.
     * ReentrantLock (not synchronized): virtual-thread-safe, no carrier pinning.
     * One thread fetches, others wait → double-check Caffeine after lock.
     */
    private String refreshWithLocalLock() {
        localRefreshLock.lock();
        try {
            // Double-check: another thread may have populated Caffeine while we waited
            CachedToken local = caffeineCache.getIfPresent(TOKEN_CACHE_KEY);
            if (local != null && !local.isExpiredOrExpiringSoon(cacheProps.refreshBufferMinutes())) {
                log.debug("Token found in Caffeine L1 after acquiring local lock (another thread refreshed)");
                return local.accessToken();
            }

            // We are the winner — fetch
            CachedToken fresh = fetcher.fetch();

            // Write to Caffeine L1 directly (Redis is down, skip it)
            caffeineCache.put(TOKEN_CACHE_KEY, fresh);
            log.info("Token written to Caffeine L1 (Redis unavailable)");

            // Best-effort write to Redis — handles the case where Redis just recovered
            tryWriteToRedis(fresh);

            // Publish invalidation so other instances (that may have stale tokens)
            // are notified — best-effort, non-fatal if Redis is still down
            invalidationPublisher.invalidate(CacheConfig.OAUTH_TOKEN_CACHE, TOKEN_CACHE_KEY);

            return fresh.accessToken();

        } finally {
            localRefreshLock.unlock();
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PRIVATE: WRITE HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Writes fresh token to Caffeine L1 and Redis L2, then publishes
     * an invalidation event so all other instances clear their stale L1.
     */
    private void writeBothLayers(CachedToken token) {
        // Write L1 (Caffeine)
        caffeineCache.put(TOKEN_CACHE_KEY, token);

        // Write L2 (Redis) — TTL managed by RedisCacheManager configuration
        writeToRedis(token);

        // Notify all other instances to clear their potentially stale Caffeine L1
        invalidationPublisher.invalidate(CacheConfig.OAUTH_TOKEN_CACHE, TOKEN_CACHE_KEY);

        log.info("Token written to Caffeine L1 + Redis L2, invalidation published. ttl={}m",
                cacheProps.redisTtlMinutes());
    }

    private void writeToRedis(CachedToken token) {
        org.springframework.cache.Cache redisCache =
                redisCacheManager.getCache(CacheConfig.OAUTH_TOKEN_CACHE);
        if (redisCache != null) {
            redisCache.put(TOKEN_CACHE_KEY, token);
        }
    }

    private void tryWriteToRedis(CachedToken token) {
        try {
            writeToRedis(token);
            log.info("Write-back: token restored to Redis L2 after recovery");
        } catch (Exception e) {
            log.debug("Redis L2 write-back skipped (still unavailable): {}", e.getMessage());
        }
    }

    private void evictFromRedis(String key) {
        try {
            org.springframework.cache.Cache redisCache =
                    redisCacheManager.getCache(CacheConfig.OAUTH_TOKEN_CACHE);
            if (redisCache != null) redisCache.evict(key);
        } catch (Exception e) {
            log.warn("Redis L2 eviction failed (non-fatal): {}", e.getMessage());
        }
    }

    private void evictAllFromRedis() {
        try {
            org.springframework.cache.Cache redisCache =
                    redisCacheManager.getCache(CacheConfig.OAUTH_TOKEN_CACHE);
            if (redisCache != null) redisCache.clear();
        } catch (Exception e) {
            log.warn("Redis L2 full eviction failed (non-fatal): {}", e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // STARTUP WARM-UP
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Eagerly primes the token cache on startup.
     * Eliminates cold-start latency on the first real payment request.
     * Failure is non-fatal — the layered fallback handles it at runtime.
     */
    @EventListener(ApplicationReadyEvent.class)
    public void warmUp() {
        log.info("Pre-warming OAuth token cache on startup");
        try {
            getToken();
            log.info("OAuth token warm-up complete");
        } catch (Exception e) {
            log.warn("OAuth token warm-up failed (will retry on first request): {}", e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // DIAGNOSTICS
    // ══════════════════════════════════════════════════════════════════════════

    public CircuitBreaker.State redisCircuitState() {
        return redisCb.getState();
    }

    public CachedToken localCacheSnapshot() {
        return caffeineCache.getIfPresent(TOKEN_CACHE_KEY);
    }

    // ── Circuit breaker event logging ─────────────────────────────────────────
    private void attachCircuitBreakerLogging() {
        redisCb.getEventPublisher()
                .onStateTransition(e ->
                        log.warn("Redis CB transition: {}", e.getStateTransition()))
                .onError(e ->
                        log.warn("Redis CB error: {}", e.getThrowable().getMessage()))
                .onSuccess(e ->
                        log.debug("Redis CB call succeeded"));
    }
}
