package com.fazil.payment.cache;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import java.time.Instant;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.redisson.api.RLock;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;

import com.github.benmanes.caffeine.cache.Caffeine;
import com.fazil.payment.config.CacheConfig;
import com.fazil.payment.config.TokenCacheProperties;
import com.fazil.payment.exception.OAuthTokenFetchException;
import com.fazil.payment.token.CachedToken;
import com.fazil.payment.token.OAuthTokenFetcher;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;

@ExtendWith(MockitoExtension.class)
class OAuthTokenCacheServiceTest {

    @Mock OAuthTokenFetcher          fetcher;
    @Mock CacheManager               redisCacheManager;
    @Mock Cache                      redisSpringCache;
    @Mock RLock                      distributedLock;
    @Mock CacheInvalidationPublisher invalidationPublisher;

    com.github.benmanes.caffeine.cache.Cache<String, CachedToken> caffeineCache;
    CircuitBreakerRegistry cbRegistry;
    TokenCacheProperties   cacheProps;
    OAuthTokenCacheService service;

    // ── Test tokens ───────────────────────────────────────────────────────────
    final CachedToken validToken    = new CachedToken("valid-token",    Instant.now().plusSeconds(1800));
    final CachedToken expiringToken = new CachedToken("expiring-token", Instant.now().plusSeconds(180)); // < 5-min buffer
    final CachedToken expiredToken  = new CachedToken("expired-token",  Instant.now().minusSeconds(600));

    @BeforeEach
    void setUp() throws InterruptedException {
        caffeineCache = Caffeine.newBuilder().maximumSize(10).build();
        cbRegistry    = CircuitBreakerRegistry.ofDefaults();
        cacheProps    = new TokenCacheProperties(25, 25, 5, 10);

        when(distributedLock.tryLock(anyLong(), anyLong(), any(TimeUnit.class))).thenReturn(true);
        when(redisCacheManager.getCache(CacheConfig.OAUTH_TOKEN_CACHE)).thenReturn(redisSpringCache);

        service = new OAuthTokenCacheService(
                fetcher, caffeineCache, redisCacheManager,
                invalidationPublisher, distributedLock, cbRegistry, cacheProps);
    }

    // ══════════════════════════════════════════════════════════════════════════
    @Nested
    @DisplayName("Layer 1 — Caffeine L1 (hot path)")
    class CaffeineL1 {

        @Test
        @DisplayName("serves valid token from Caffeine without any network call")
        void servesFromCaffeineImmediately() {
            caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);

            // Spy to verify getFromCaffeineCache() returns the token
            OAuthTokenCacheService spy = spy(service);
            doReturn(validToken).when(spy).getFromCaffeineCache();

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verifyNoInteractions(fetcher);
            verifyNoInteractions(redisCacheManager); // Redis never touched
        }

        @Test
        @DisplayName("falls through to Redis L2 when Caffeine is cold")
        void fallsThroughToRedisOnCaffeineMiss() {
            // Caffeine cold → @Cacheable returns null
            OAuthTokenCacheService spy = spy(service);
            doReturn(null).when(spy).getFromCaffeineCache();

            // Redis L2 has the token
            when(redisSpringCache.get(OAuthTokenCacheService.TOKEN_CACHE_KEY))
                    .thenReturn(() -> validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verifyNoInteractions(fetcher);
        }

        @Test
        @DisplayName("falls through when Caffeine token is expiring soon")
        void fallsThroughWhenCaffeineTokenExpiringSoon() {
            OAuthTokenCacheService spy = spy(service);
            doReturn(expiringToken).when(spy).getFromCaffeineCache();

            // Redis L2 has fresh token
            when(redisSpringCache.get(OAuthTokenCacheService.TOKEN_CACHE_KEY))
                    .thenReturn(() -> validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verifyNoInteractions(fetcher);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    @Nested
    @DisplayName("Layer 2 — Redis L2")
    class RedisL2 {

        @Test
        @DisplayName("populates Caffeine L1 when Redis L2 has valid token")
        void populatesCaffeineAfterRedisHit() {
            OAuthTokenCacheService spy = spy(service);
            doReturn(null).when(spy).getFromCaffeineCache();

            when(redisSpringCache.get(OAuthTokenCacheService.TOKEN_CACHE_KEY))
                    .thenReturn(() -> validToken);

            spy.getToken();

            // Caffeine L1 should now be populated for next request
            CachedToken stored = caffeineCache.getIfPresent(OAuthTokenCacheService.TOKEN_CACHE_KEY);
            assertThat(stored).isNotNull();
            assertThat(stored.accessToken()).isEqualTo("valid-token");
        }

        @Test
        @DisplayName("fetches new token when Redis L2 is empty")
        void fetchesWhenRedisMiss() throws Exception {
            OAuthTokenCacheService spy = spy(service);
            doReturn(null).when(spy).getFromCaffeineCache();

            // Redis L2 miss
            when(redisSpringCache.get(OAuthTokenCacheService.TOKEN_CACHE_KEY))
                    .thenReturn(null);
            when(fetcher.fetch()).thenReturn(validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verify(fetcher).fetch();
        }

        @Test
        @DisplayName("uses distributed lock on Redis L2 miss")
        void usesDistributedLockOnRedisMiss() throws Exception {
            OAuthTokenCacheService spy = spy(service);
            doReturn(null).when(spy).getFromCaffeineCache();
            when(redisSpringCache.get(anyString())).thenReturn(null);
            when(fetcher.fetch()).thenReturn(validToken);

            spy.getToken();

            verify(distributedLock).tryLock(5, 10, TimeUnit.SECONDS);
            verify(distributedLock).unlock();
        }

        @Test
        @DisplayName("double-check: skips fetch if another instance refreshed while waiting for lock")
        void distributedLockDoubleCheck() throws Exception {
            OAuthTokenCacheService spy = spy(service);
            doReturn(null).when(spy).getFromCaffeineCache();

            // First Redis read: miss. After lock acquired: hit (another instance refreshed)
            when(redisSpringCache.get(OAuthTokenCacheService.TOKEN_CACHE_KEY))
                    .thenReturn(null)
                    .thenReturn(() -> validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verifyNoInteractions(fetcher); // lock acquired, double-check passed, no fetch
        }

        @Test
        @DisplayName("writes both Caffeine L1 and Redis L2 after fetch")
        void writesBothLayersAfterFetch() throws Exception {
            OAuthTokenCacheService spy = spy(service);
            doReturn(null).when(spy).getFromCaffeineCache();
            when(redisSpringCache.get(anyString())).thenReturn(null);
            when(fetcher.fetch()).thenReturn(validToken);

            spy.getToken();

            // L1 written
            assertThat(caffeineCache.getIfPresent(OAuthTokenCacheService.TOKEN_CACHE_KEY))
                    .isNotNull();
            // L2 written
            verify(redisSpringCache).put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);
            // Invalidation published to other instances
            verify(invalidationPublisher).invalidate(
                    CacheConfig.OAUTH_TOKEN_CACHE, OAuthTokenCacheService.TOKEN_CACHE_KEY);
        }

        @Test
        @DisplayName("skips Redis L2 when circuit breaker is open")
        void skipsRedisWhenCircuitOpen() {
            CircuitBreaker cb = cbRegistry.circuitBreaker("redis-oauth");
            cb.transitionToOpenState();

            OAuthTokenCacheService spy = spy(service);
            doReturn(null).when(spy).getFromCaffeineCache();
            when(fetcher.fetch()).thenReturn(validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verifyNoInteractions(redisSpringCache); // Redis entirely bypassed
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    @Nested
    @DisplayName("Layer 3 — Direct OAuth fetch (Redis unavailable)")
    class DirectFetch {

        @Test
        @DisplayName("fetches and writes Caffeine L1 when Redis is down")
        void fetchesAndWritesCaffeineWhenRedisDown() {
            OAuthTokenCacheService spy = spy(service);
            doReturn(null).when(spy).getFromCaffeineCache();
            when(redisCacheManager.getCache(anyString()))
                    .thenThrow(new RuntimeException("Redis connection refused"));
            when(fetcher.fetch()).thenReturn(validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            assertThat(caffeineCache.getIfPresent(OAuthTokenCacheService.TOKEN_CACHE_KEY))
                    .isNotNull();
        }

        @Test
        @DisplayName("local ReentrantLock prevents concurrent duplicate fetches")
        void localLockDoubleCheck() {
            OAuthTokenCacheService spy = spy(service);
            doReturn(null).when(spy).getFromCaffeineCache();
            when(redisCacheManager.getCache(anyString()))
                    .thenThrow(new RuntimeException("Redis down"));

            // Simulate another thread populating Caffeine before our fetch
            caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verifyNoInteractions(fetcher); // double-check passed, no fetch needed
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    @Nested
    @DisplayName("Eviction")
    class Eviction {

        @Test
        @DisplayName("evictToken publishes invalidation to other instances")
        void evictPublishesInvalidation() {
            service.evictToken();

            verify(invalidationPublisher).invalidate(
                    CacheConfig.OAUTH_TOKEN_CACHE,
                    OAuthTokenCacheService.TOKEN_CACHE_KEY);
        }

        @Test
        @DisplayName("evictAllTokens publishes full invalidation")
        void evictAllPublishesFullInvalidation() {
            service.evictAllTokens();

            verify(invalidationPublisher).invalidateAll(CacheConfig.OAUTH_TOKEN_CACHE);
        }

        @Test
        @DisplayName("evictToken clears Caffeine L1 directly")
        void evictClearsCaffeineL1() {
            caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);

            service.evictToken();

            // @CacheEvict on caffeineCacheManager clears it
            // In unit test context without Spring proxy, we verify the publisher was called
            verify(invalidationPublisher).invalidate(anyString(), anyString());
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    @Nested
    @DisplayName("All layers fail")
    class AllFail {

        @Test
        @DisplayName("throws OAuthTokenFetchException when all layers fail")
        void throwsWhenEverythingFails() {
            OAuthTokenCacheService spy = spy(service);
            doReturn(null).when(spy).getFromCaffeineCache();
            when(redisCacheManager.getCache(anyString()))
                    .thenThrow(new RuntimeException("Redis down"));
            when(fetcher.fetch())
                    .thenThrow(new OAuthTokenFetchException("OAuth server unreachable"));

            assertThatThrownBy(spy::getToken)
                    .isInstanceOf(OAuthTokenFetchException.class)
                    .hasMessageContaining("OAuth server unreachable");
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    @Nested
    @DisplayName("Pub/sub invalidation subscriber")
    class InvalidationSubscriber {

        @Test
        @DisplayName("subscriber clears single Caffeine L1 entry on message")
        void subscriberClearsSingleEntry() {
            caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);

            CacheInvalidationSubscriber subscriber =
                    new CacheInvalidationSubscriber(caffeineCache);

            subscriber.onInvalidationMessage(
                    CacheConfig.OAUTH_TOKEN_CACHE + ":" + OAuthTokenCacheService.TOKEN_CACHE_KEY);

            assertThat(caffeineCache.getIfPresent(OAuthTokenCacheService.TOKEN_CACHE_KEY)).isNull();
        }

        @Test
        @DisplayName("subscriber clears all Caffeine L1 entries on wildcard message")
        void subscriberClearsAllEntriesOnWildcard() {
            caffeineCache.put("provider::gateway", validToken);
            caffeineCache.put("provider::other",   validToken);

            CacheInvalidationSubscriber subscriber =
                    new CacheInvalidationSubscriber(caffeineCache);

            subscriber.onInvalidationMessage(CacheConfig.OAUTH_TOKEN_CACHE + ":*");

            assertThat(caffeineCache.estimatedSize()).isZero();
        }

        @Test
        @DisplayName("subscriber ignores messages for unknown caches")
        void subscriberIgnoresUnknownCaches() {
            caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);

            CacheInvalidationSubscriber subscriber =
                    new CacheInvalidationSubscriber(caffeineCache);

            subscriber.onInvalidationMessage("merchant-config:some-key");

            // oauth-tokens Caffeine entry untouched
            assertThat(caffeineCache.getIfPresent(OAuthTokenCacheService.TOKEN_CACHE_KEY))
                    .isNotNull();
        }

        @Test
        @DisplayName("subscriber ignores blank messages gracefully")
        void subscriberIgnoresBlankMessage() {
            CacheInvalidationSubscriber subscriber =
                    new CacheInvalidationSubscriber(caffeineCache);

            // Should not throw
            subscriber.onInvalidationMessage("");
            subscriber.onInvalidationMessage(null);
        }
    }
}
