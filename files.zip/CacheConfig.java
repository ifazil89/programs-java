package com.fazil.payment.config;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.fazil.payment.token.CachedToken;

/**
 * Central cache configuration.
 *
 * Two CacheManagers are registered:
 *
 *   1. redisCacheManager  (@Primary) — Spring @Cacheable uses this by default.
 *      Stores tokens in Redis with per-cache TTL.
 *      Disabled/bypassed transparently when Redis is unreachable (circuit breaker).
 *
 *   2. caffeineCacheManager — used explicitly by OAuthTokenCacheService as L2.
 *      Per-instance in-process cache. Never goes down (no external dependency).
 *
 * The Caffeine Cache<String, CachedToken> bean is also registered separately
 * so OAuthTokenCacheService can use it directly (for proactive refresh buffer
 * and isExpiredOrExpiringSoon() checks that @Cacheable cannot do).
 *
 * Why not Spring's @Cacheable alone?
 *   - @Cacheable has no proactive refresh buffer (tokens expire mid-flight).
 *   - @Cacheable cannot express Redis → Caffeine → Direct fallback with a
 *     circuit breaker. The OAuthTokenCacheService wraps @Cacheable and adds
 *     the missing resilience on top.
 */
@Configuration
@EnableCaching
public class CacheConfig {

    // ── Cache name constants — single source of truth ─────────────────────────
    public static final String OAUTH_TOKEN_CACHE = "oauth-tokens";

    // ── Redis L1 CacheManager (@Primary — default for @Cacheable) ─────────────
    /**
     * RedisCacheManager with:
     *   - JSON serialization (human-readable in Redis, survives class renames)
     *   - Per-cache TTL driven by TokenCacheProperties
     *   - Null values NOT cached (prevents caching a failed fetch)
     *   - Key prefix: "payment-gateway::" for namespace isolation in shared Redis
     */
    @Bean("redisCacheManager")
    @Primary
    public CacheManager redisCacheManager(
            RedisConnectionFactory factory,
            TokenCacheProperties cacheProps) {

        // Base config applied to ALL caches unless overridden per-cache
        RedisCacheConfiguration defaultConfig = RedisCacheConfiguration
                .defaultCacheConfig()
                .prefixCacheNameWith("payment-gateway::")   // namespace in Redis
                .disableCachingNullValues()
                .serializeKeysWith(
                        RedisSerializationContext.SerializationPair
                                .fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(
                        RedisSerializationContext.SerializationPair
                                .fromSerializer(new GenericJackson2JsonRedisSerializer()));

        // Per-cache override — oauth-tokens gets its own TTL
        RedisCacheConfiguration oauthTokenConfig = defaultConfig
                .entryTtl(Duration.ofMinutes(cacheProps.redisTtlMinutes()));

        return RedisCacheManager.builder(factory)
                .cacheDefaults(defaultConfig)
                .withCacheConfiguration(OAUTH_TOKEN_CACHE, oauthTokenConfig)
                // Add more named caches here as you grow:
                // .withCacheConfiguration("merchant-config", merchantConfig)
                // .withCacheConfiguration("payment-routes", routeConfig)
                .transactionAware()    // participates in Spring TX if needed
                .build();
    }

    // ── Caffeine L2 CacheManager (explicit, used as fallback) ─────────────────
    /**
     * CaffeineCacheManager with per-cache TTL mirroring Redis.
     * Used explicitly via cacheManager = "caffeineCacheManager" on annotations,
     * and also as the L2 fallback in OAuthTokenCacheService when Redis is down.
     */
    @Bean("caffeineCacheManager")
    public CacheManager caffeineCacheManager(TokenCacheProperties cacheProps) {
        org.springframework.cache.caffeine.CaffeineCacheManager manager =
                new org.springframework.cache.caffeine.CaffeineCacheManager();

        // Register oauth-tokens with its own Caffeine spec
        manager.registerCustomCache(OAUTH_TOKEN_CACHE,
                Caffeine.newBuilder()
                        .expireAfterWrite(cacheProps.caffeineTtlMinutes(), TimeUnit.MINUTES)
                        .maximumSize(cacheProps.maxCaffeineSize())
                        .recordStats()                      // exposes hit/miss to Micrometer
                        .build());

        // Add more named caches here in future:
        // manager.registerCustomCache("merchant-config", ...)

        return manager;
    }

    // ── Raw Caffeine Cache<String, CachedToken> ───────────────────────────────
    /**
     * Separate typed bean used directly by OAuthTokenCacheService for:
     *   1. isExpiredOrExpiringSoon() check (proactive refresh buffer).
     *   2. L2 fallback read/write when Redis is unavailable.
     *   3. Write-back to Caffeine after a direct OAuth fetch.
     *
     * This is a LOWER LEVEL than the CaffeineCacheManager above.
     * Both exist: the CacheManager is for @Cacheable annotation support,
     * this typed bean is for programmatic access with full type safety.
     */
    @Bean("oauthTokenLocalCache")
    public Cache<String, CachedToken> oauthTokenLocalCache(TokenCacheProperties cacheProps) {
        return Caffeine.newBuilder()
                .expireAfterWrite(cacheProps.caffeineTtlMinutes(), TimeUnit.MINUTES)
                .maximumSize(cacheProps.maxCaffeineSize())
                .recordStats()
                .build();
    }

    // ── Redisson distributed lock ─────────────────────────────────────────────
    /**
     * Prevents thundering herd: when Redis L1 is empty, only ONE instance
     * fetches a new token. All others wait behind this lock and reuse the result.
     */
    @Bean("oauthTokenRefreshLock")
    public RLock oauthTokenRefreshLock(RedissonClient redisson) {
        return redisson.getLock("oauth:token:refresh:lock");
    }

    // ── RestClient for OAuth token endpoint ───────────────────────────────────
    @Bean("oauthRestClient")
    public RestClient oauthRestClient(OAuthProviderProperties props) {
        var factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout((int) props.connectTimeout().toMillis());
        factory.setReadTimeout((int) props.readTimeout().toMillis());

        return RestClient.builder()
                .baseUrl(props.tokenUrl())
                .requestFactory(factory)
                .build();
    }
}
