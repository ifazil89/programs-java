package com.fazil.payment.token;

import java.io.Serial;
import java.io.Serializable;
import java.time.Duration;
import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Immutable token value object stored in both Redis L1 and Caffeine L2.
 *
 * Implements Serializable for Redis JSON serialization via Jackson.
 * Jackson annotations are explicit to survive potential record/class rename.
 *
 * NEVER log accessToken — only expiresAt.
 */
public record CachedToken(

        @JsonProperty("accessToken") String  accessToken,
        @JsonProperty("expiresAt")   Instant expiresAt

) implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    // Required for Jackson deserialization of records
    @JsonCreator
    public CachedToken(
            @JsonProperty("accessToken") String  accessToken,
            @JsonProperty("expiresAt")   Instant expiresAt) {
        this.accessToken = accessToken;
        this.expiresAt   = expiresAt;
    }

    /**
     * True if token is expired OR within the proactive refresh buffer window.
     * Buffer is injected from config — default 5 minutes.
     */
    public boolean isExpiredOrExpiringSoon(int refreshBufferMinutes) {
        return Instant.now().isAfter(expiresAt.minus(Duration.ofMinutes(refreshBufferMinutes)));
    }

    /**
     * Remaining validity as a Duration (negative = already expired).
     */
    public Duration remainingValidity() {
        return Duration.between(Instant.now(), expiresAt);
    }

    @Override
    public String toString() {
        // Safety: never expose token value in logs, toString, or serialized output
        return "CachedToken[accessToken=****, expiresAt=" + expiresAt + "]";
    }
}
