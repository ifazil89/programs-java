package com.fazil.payment.config;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Binds to oauth.provider.* in application.yml.
 * All fields are validated at startup — fails fast before the app is ready.
 */
@Validated
@ConfigurationProperties(prefix = "oauth.provider")
public record OAuthProviderProperties(

        @NotBlank String tokenUrl,
        @NotBlank String clientId,
        @NotBlank String clientSecret,
        @NotBlank String scope,

        @NotNull Duration connectTimeout,
        @NotNull Duration readTimeout
) {}
