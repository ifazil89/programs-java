package com.fazil.payment.cache;

import java.time.Duration;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import org.redisson.api.RLock;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import com.github.benmanes.caffeine.cache.Cache.Policy;
import com.fazil.payment.config.CacheConfig;
import com.fazil.payment.config.TokenCacheProperties;
import com.fazil.payment.token.CachedToken;
import com.fazil.payment.token.OAuthTokenFetcher;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import lombok.extern.slf4j.Slf4j;

/**
 * Production-grade OAuth token cache service.
 *
 * ┌─────────────────────────────────────────────────────────────┐
 * │                    getToken() call flow                     │
 * │                                                             │
 * │  1. @Cacheable(redisCacheManager) ──► Redis GET             │
 * │     Hit  → return token (fast path, lock-free)              │
 * │     Miss → enter refresh path                               │
 * │                                                             │
 * │  2. Redis unavailable (CB OPEN or exception)                │
 * │     → Caffeine L2 getIfPresent()                            │
 * │       Hit + not expiring → return token                     │
 * │       Miss / expiring   → enter refresh path                │
 * │                                                             │
 * │  3. Refresh path                                            │
 * │     Redis UP  → Redisson distributed lock → fetch           │
 * │                 → write Redis + Caffeine                    │
 * │     Redis DOWN → ReentrantLock (local) → fetch              │
 * │                 → write Caffeine only                       │
 * │                 → best-effort Redis write-back              │
 * └─────────────────────────────────────────────────────────────┘
 *
 * Threading:
 *   • Hot path (cache hits) is lock-free.
 *   • ReentrantLock — not synchronized — so Java 21 virtual threads
 *     never pin to a carrier thread.
 *   • Double-checked locking prevents thundering herd in both paths.
 *
 * Cache key design:
 *   Cache name : "oauth-tokens"
 *   Key        : "provider::gateway"   (provider namespace + fixed name)
 *
 *   In Redis     → "payment-gateway::oauth-tokens::provider::gateway"
 *   In Caffeine  → "provider::gateway"
 *
 *   This key format makes it trivial to add per-provider tokens later:
 *   just change the key to "provider::stripe", "provider::adyen" etc.
 */
@Slf4j
@Service
public class OAuthTokenCacheService {

    // ── Cache key — single source of truth ────────────────────────────────────
    static final String TOKEN_CACHE_KEY    = "provider::gateway";
    private static final String REDIS_CB_NAME = "redis-oauth";

    // ── Redis raw key (for StringRedisTemplate direct ops in fallback path) ───
    // Mirrors RedisCacheManager key format: <prefix><cacheName>::<key>
    private static final String REDIS_RAW_KEY =
            "payment-gateway::" + CacheConfig.OAUTH_TOKEN_CACHE + "::" + TOKEN_CACHE_KEY;

    private final OAuthTokenFetcher                   fetcher;
    private final StringRedisTemplate                 redisTemplate;
    private final com.github.benmanes.caffeine.cache.Cache<String, CachedToken> caffeineCache;
    private final CacheManager                        redisCacheManager;
    private final CacheManager                        caffeineCacheManager;
    private final RLock                               distributedLock;
    private final CircuitBreaker                      redisCb;
    private final TokenCacheProperties                cacheProps;

    /** Local lock used ONLY when Redis is down (no distributed lock available) */
    private final ReentrantLock localRefreshLock = new ReentrantLock();

    public OAuthTokenCacheService(
            OAuthTokenFetcher fetcher,
            StringRedisTemplate redisTemplate,
            @Qualifier("oauthTokenLocalCache")
            com.github.benmanes.caffeine.cache.Cache<String, CachedToken> caffeineCache,
            @Qualifier("redisCacheManager")    CacheManager redisCacheManager,
            @Qualifier("caffeineCacheManager") CacheManager caffeineCacheManager,
            @Qualifier("oauthTokenRefreshLock") RLock distributedLock,
            CircuitBreakerRegistry cbRegistry,
            TokenCacheProperties cacheProps) {

        this.fetcher              = fetcher;
        this.redisTemplate        = redisTemplate;
        this.caffeineCache        = caffeineCache;
        this.redisCacheManager    = redisCacheManager;
        this.caffeineCacheManager = caffeineCacheManager;
        this.distributedLock      = distributedLock;
        this.redisCb              = cbRegistry.circuitBreaker(REDIS_CB_NAME);
        this.cacheProps           = cacheProps;

        attachCircuitBreakerLogging();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Returns a valid Bearer token string, never null.
     *
     * The full 3-layer logic lives here.
     * Callers simply call getToken() — all fallback, refresh, and
     * circuit-breaking is transparent.
     */
    public String getToken() {
        // ── Layer 1: Redis via Spring @Cacheable (circuit-broken) ─────────────
        try {
            CachedToken redisToken = redisCb.executeCallable(
                    () -> getFromRedisCache());

            if (redisToken != null && !redisToken.isExpiredOrExpiringSoon(cacheProps.refreshBufferMinutes())) {
                log.debug("Token served from Redis L1, remaining={}", redisToken.remainingValidity());
                return redisToken.accessToken();
            }

            // Redis up, but cache empty or expiring → refresh via distributed lock
            log.debug("Redis L1 miss or token expiring soon — refreshing via distributed lock");
            return refreshViaRedis();

        } catch (CallNotPermittedException e) {
            log.warn("Redis CB {} — falling back to Caffeine L2", redisCb.getState());
        } catch (Exception e) {
            log.warn("Redis L1 error [{}]: {} — falling back to Caffeine L2",
                    e.getClass().getSimpleName(), e.getMessage());
        }

        // ── Layer 2: Caffeine (in-process) ────────────────────────────────────
        CachedToken local = caffeineCache.getIfPresent(TOKEN_CACHE_KEY);
        if (local != null && !local.isExpiredOrExpiringSoon(cacheProps.refreshBufferMinutes())) {
            log.debug("Token served from Caffeine L2, remaining={}", local.remainingValidity());
            return local.accessToken();
        }

        // ── Layer 3: Direct fetch (all caches cold or Redis down) ─────────────
        log.info("All caches cold/expiring — fetching directly from OAuth server");
        return refreshDirectly();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // CACHEABLE READ — Spring @Cacheable annotation on private helper
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Spring @Cacheable on this method wires the Redis CacheManager.
     * When the key is present in Redis → returns the value without calling the body.
     * When the key is absent → body is called, result stored in Redis, returned.
     *
     * Key  : TOKEN_CACHE_KEY = "provider::gateway"
     * Cache: "oauth-tokens" in Redis with TTL from RedisCacheManager config.
     *
     * NOTE: This method is intentionally package-private so only this class
     * calls it. The public entry point is getToken() which adds resilience
     * that @Cacheable alone cannot provide.
     */
    @Cacheable(
            value        = CacheConfig.OAUTH_TOKEN_CACHE,
            key          = "'" + TOKEN_CACHE_KEY + "'",
            cacheManager = "redisCacheManager",
            unless       = "#result == null"
    )
    CachedToken getFromRedisCache() {
        // This body executes ONLY on a Redis cache miss.
        // Returns null so @Cacheable skips storage — actual storage is done
        // in refreshViaRedis() with proper distributed locking.
        log.debug("@Cacheable Redis miss for key={}", TOKEN_CACHE_KEY);
        return null;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // CACHE EVICTION
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Evicts the token from Redis AND Caffeine.
     * Call this after rotating OAuth client credentials.
     *
     * @CacheEvict removes the entry from Redis via Spring's cache abstraction.
     * Caffeine eviction is done manually (Spring @CacheEvict only targets one
     * CacheManager per annotation).
     */
    @CacheEvict(
            value        = CacheConfig.OAUTH_TOKEN_CACHE,
            key          = "'" + TOKEN_CACHE_KEY + "'",
            cacheManager = "redisCacheManager"
    )
    public void evictToken() {
        log.warn("Token evicted from Redis L1 by explicit request");
        caffeineCache.invalidate(TOKEN_CACHE_KEY);
        log.warn("Token evicted from Caffeine L2 by explicit request");
    }

    /**
     * Evicts ALL entries in the oauth-tokens cache (Redis + Caffeine).
     * Use after a full credential rotation or emergency revoke.
     */
    @CacheEvict(
            value        = CacheConfig.OAUTH_TOKEN_CACHE,
            allEntries   = true,
            cacheManager = "redisCacheManager"
    )
    public void evictAllTokens() {
        log.warn("All tokens evicted from Redis L1");
        caffeineCache.invalidateAll();
        log.warn("All tokens evicted from Caffeine L2");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PRIVATE: REFRESH PATHS
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Refresh path when Redis is reachable.
     * Uses Redisson distributed lock — only one instance fetches at a time.
     * All others wait, then read the token the winner wrote.
     */
    private String refreshViaRedis() throws Exception {
        boolean locked = distributedLock.tryLock(5, 10, TimeUnit.SECONDS);
        try {
            // Double-check: another instance may have refreshed while we waited
            CachedToken rechecked = getFromRedisCache();
            if (rechecked != null && !rechecked.isExpiredOrExpiringSoon(cacheProps.refreshBufferMinutes())) {
                log.debug("Token found in Redis after acquiring lock (another instance refreshed)");
                return rechecked.accessToken();
            }

            // We are the winner — fetch and store
            CachedToken fresh = fetcher.fetch();
            storeInRedis(fresh);
            caffeineCache.put(TOKEN_CACHE_KEY, fresh);  // keep L2 warm too

            log.info("Token stored in Redis L1 + Caffeine L2, ttl={}m", cacheProps.redisTtlMinutes());
            return fresh.accessToken();

        } finally {
            if (locked) distributedLock.unlock();
        }
    }

    /**
     * Refresh path when Redis is down.
     * Uses local ReentrantLock — virtual-thread-safe (no carrier pinning).
     * One thread fetches, all others wait and reuse via Caffeine double-check.
     */
    private String refreshDirectly() {
        localRefreshLock.lock();
        try {
            // Double-check after acquiring local lock
            CachedToken local = caffeineCache.getIfPresent(TOKEN_CACHE_KEY);
            if (local != null && !local.isExpiredOrExpiringSoon(cacheProps.refreshBufferMinutes())) {
                log.debug("Token found in Caffeine after acquiring local lock (another thread refreshed)");
                return local.accessToken();
            }

            CachedToken fresh = fetcher.fetch();
            caffeineCache.put(TOKEN_CACHE_KEY, fresh);
            log.info("Token stored in Caffeine L2 (Redis unavailable), ttl={}m",
                    cacheProps.caffeineTtlMinutes());

            // Best-effort write-back to Redis — if it just recovered, prime it
            tryWriteBackToRedis(fresh);

            return fresh.accessToken();

        } finally {
            localRefreshLock.unlock();
        }
    }

    /**
     * Stores token in Redis via Spring Cache abstraction so TTL is applied
     * by the RedisCacheManager configuration (no manual Duration arithmetic).
     */
    private void storeInRedis(CachedToken token) {
        Cache redisCache = redisCacheManager.getCache(CacheConfig.OAUTH_TOKEN_CACHE);
        if (redisCache != null) {
            redisCache.put(TOKEN_CACHE_KEY, token);
        }
    }

    private void tryWriteBackToRedis(CachedToken token) {
        try {
            storeInRedis(token);
            log.info("Write-back: token restored to Redis L1 after direct fetch");
        } catch (Exception e) {
            log.debug("Redis write-back skipped (still unavailable): {}", e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // STARTUP WARM-UP
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Pre-fetches a token at startup so the first real request is never cold.
     * Failure is non-fatal — circuit breaker + fallback handles it at runtime.
     */
    @EventListener(ApplicationReadyEvent.class)
    public void warmUp() {
        log.info("Pre-warming OAuth token cache on startup");
        try {
            String token = getToken();
            log.info("OAuth token warm-up complete, token present={}", token != null);
        } catch (Exception e) {
            log.warn("OAuth token warm-up failed (will retry on first request): {}", e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // DIAGNOSTICS (for HealthIndicator and TokenDiagnosticController)
    // ══════════════════════════════════════════════════════════════════════════

    public CircuitBreaker.State redisCircuitState() {
        return redisCb.getState();
    }

    public CachedToken localCacheSnapshot() {
        return caffeineCache.getIfPresent(TOKEN_CACHE_KEY);
    }

    // ── Circuit breaker event logging ─────────────────────────────────────────
    private void attachCircuitBreakerLogging() {
        redisCb.getEventPublisher()
                .onStateTransition(e ->
                        log.warn("Redis CB transition: {}", e.getStateTransition()))
                .onError(e ->
                        log.warn("Redis CB error: {}", e.getThrowable().getMessage()))
                .onSuccess(e ->
                        log.debug("Redis CB call succeeded"));
    }
}
