package com.fazil.payment.cache;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import java.time.Instant;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.redisson.api.RLock;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.core.StringRedisTemplate;

import com.github.benmanes.caffeine.cache.Caffeine;
import com.fazil.payment.config.TokenCacheProperties;
import com.fazil.payment.exception.OAuthTokenFetchException;
import com.fazil.payment.token.CachedToken;
import com.fazil.payment.token.OAuthTokenFetcher;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;

@ExtendWith(MockitoExtension.class)
class OAuthTokenCacheServiceTest {

    @Mock OAuthTokenFetcher fetcher;
    @Mock StringRedisTemplate redisTemplate;
    @Mock CacheManager redisCacheManager;
    @Mock CacheManager caffeineCacheManager;
    @Mock Cache redisCache;
    @Mock RLock distributedLock;

    com.github.benmanes.caffeine.cache.Cache<String, CachedToken> caffeineCache;
    CircuitBreakerRegistry cbRegistry;
    TokenCacheProperties   cacheProps;
    OAuthTokenCacheService service;

    // Token valid for 30 min — NOT expiring soon
    final CachedToken validToken   = new CachedToken("valid-token",   Instant.now().plusSeconds(1800));
    // Token valid for 3 min — WILL be caught by 5-min buffer
    final CachedToken expiringToken = new CachedToken("expiring-token", Instant.now().plusSeconds(180));
    // Token expired 10 min ago
    final CachedToken expiredToken  = new CachedToken("expired-token",  Instant.now().minusSeconds(600));

    @BeforeEach
    void setUp() throws InterruptedException {
        caffeineCache = Caffeine.newBuilder().maximumSize(10).build();
        cbRegistry    = CircuitBreakerRegistry.ofDefaults();
        cacheProps    = new TokenCacheProperties(25, 25, 5, 10);

        when(distributedLock.tryLock(anyLong(), anyLong(), any(TimeUnit.class))).thenReturn(true);
        when(redisCacheManager.getCache(anyString())).thenReturn(redisCache);

        service = new OAuthTokenCacheService(
                fetcher, redisTemplate, caffeineCache,
                redisCacheManager, caffeineCacheManager,
                distributedLock, cbRegistry, cacheProps);
    }

    // ── Spy to control getFromRedisCache() return value ───────────────────────
    OAuthTokenCacheService spyService() {
        return spy(service);
    }

    @Nested
    @DisplayName("Layer 1 — Redis")
    class RedisLayer {

        @Test
        @DisplayName("serves valid token from Redis without fetching")
        void servesFromRedis() {
            OAuthTokenCacheService spy = spyService();
            doReturn(validToken).when(spy).getFromRedisCache();

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verifyNoInteractions(fetcher);
        }

        @Test
        @DisplayName("refreshes when Redis token is expiring soon")
        void refreshesWhenRedisTokenExpiring() throws Exception {
            OAuthTokenCacheService spy = spyService();
            // First call returns expiring token, second (post-lock double-check) returns null
            doReturn(expiringToken).doReturn(null).when(spy).getFromRedisCache();
            when(fetcher.fetch()).thenReturn(validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verify(fetcher, times(1)).fetch();
        }

        @Test
        @DisplayName("uses distributed lock — only one fetch when Redis miss")
        void usesDistributedLock() throws Exception {
            OAuthTokenCacheService spy = spyService();
            doReturn(null).when(spy).getFromRedisCache();
            when(fetcher.fetch()).thenReturn(validToken);

            spy.getToken();

            verify(distributedLock).tryLock(5, 10, TimeUnit.SECONDS);
            verify(distributedLock).unlock();
        }

        @Test
        @DisplayName("double-check: skips fetch if another instance refreshed while waiting for lock")
        void doubleCheckPreventsDoubleRefresh() throws Exception {
            OAuthTokenCacheService spy = spyService();
            // Miss first, then another instance writes it while we waited
            doReturn(null).doReturn(validToken).when(spy).getFromRedisCache();

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verifyNoInteractions(fetcher); // lock acquired but fetch skipped
        }
    }

    @Nested
    @DisplayName("Layer 2 — Caffeine fallback")
    class CaffeineLayer {

        @Test
        @DisplayName("serves from Caffeine when Redis circuit is open")
        void servesFromCaffeineWhenRedisCbOpen() {
            // Trip the circuit breaker
            CircuitBreaker cb = cbRegistry.circuitBreaker("redis-oauth");
            cb.transitionToOpenState();

            caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);

            String token = service.getToken();

            assertThat(token).isEqualTo("valid-token");
            verifyNoInteractions(fetcher);
        }

        @Test
        @DisplayName("serves from Caffeine when Redis throws exception")
        void servesFromCaffeineOnRedisException() {
            OAuthTokenCacheService spy = spyService();
            doThrow(new RuntimeException("Redis connection refused"))
                    .when(spy).getFromRedisCache();

            caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verifyNoInteractions(fetcher);
        }

        @Test
        @DisplayName("does NOT serve expiring Caffeine token — escalates to fetch")
        void doesNotServeExpiringLocalToken() {
            OAuthTokenCacheService spy = spyService();
            doThrow(new RuntimeException("Redis down")).when(spy).getFromRedisCache();
            caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, expiringToken);
            when(fetcher.fetch()).thenReturn(validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verify(fetcher, times(1)).fetch();
        }
    }

    @Nested
    @DisplayName("Layer 3 — Direct fetch fallback")
    class DirectFetchLayer {

        @Test
        @DisplayName("fetches directly when all caches are cold")
        void fetchesDirectlyWhenAllCachesCold() {
            OAuthTokenCacheService spy = spyService();
            doThrow(new RuntimeException("Redis down")).when(spy).getFromRedisCache();
            // caffeineCache is empty
            when(fetcher.fetch()).thenReturn(validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
            verify(fetcher).fetch();
        }

        @Test
        @DisplayName("stores fetched token in Caffeine L2 after direct fetch")
        void storesFreshTokenInCaffeineAfterDirectFetch() {
            OAuthTokenCacheService spy = spyService();
            doThrow(new RuntimeException("Redis down")).when(spy).getFromRedisCache();
            when(fetcher.fetch()).thenReturn(validToken);

            spy.getToken();

            CachedToken stored = caffeineCache.getIfPresent(OAuthTokenCacheService.TOKEN_CACHE_KEY);
            assertThat(stored).isNotNull();
            assertThat(stored.accessToken()).isEqualTo("valid-token");
        }

        @Test
        @DisplayName("double-check: second thread reuses token from Caffeine populated by first thread")
        void localDoubleCheckPreventsDoubleRefresh() {
            OAuthTokenCacheService spy = spyService();
            doThrow(new RuntimeException("Redis down")).when(spy).getFromRedisCache();
            // Simulate another thread putting token in Caffeine before we fetch
            when(fetcher.fetch()).thenAnswer(inv -> {
                caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);
                throw new AssertionError("fetch() should not have been reached — Caffeine had the token");
            });

            // Pre-populate as if another thread just did it
            caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);

            String token = spy.getToken();

            assertThat(token).isEqualTo("valid-token");
        }
    }

    @Nested
    @DisplayName("Eviction")
    class Eviction {

        @Test
        @DisplayName("evictToken removes from Caffeine")
        void evictTokenClearsCaffeine() {
            caffeineCache.put(OAuthTokenCacheService.TOKEN_CACHE_KEY, validToken);
            assertThat(caffeineCache.getIfPresent(OAuthTokenCacheService.TOKEN_CACHE_KEY)).isNotNull();

            service.evictToken();

            assertThat(caffeineCache.getIfPresent(OAuthTokenCacheService.TOKEN_CACHE_KEY)).isNull();
        }

        @Test
        @DisplayName("evictAllTokens clears entire Caffeine cache")
        void evictAllClearsCaffeine() {
            caffeineCache.put("provider::gateway", validToken);
            caffeineCache.put("provider::other",   validToken);

            service.evictAllTokens();

            assertThat(caffeineCache.estimatedSize()).isZero();
        }
    }

    @Nested
    @DisplayName("All layers fail")
    class AllLayersFail {

        @Test
        @DisplayName("throws OAuthTokenFetchException when provider is also unreachable")
        void throwsWhenAllFail() {
            OAuthTokenCacheService spy = spyService();
            doThrow(new RuntimeException("Redis down")).when(spy).getFromRedisCache();
            when(fetcher.fetch()).thenThrow(new OAuthTokenFetchException("Provider unreachable"));

            assertThatThrownBy(spy::getToken)
                    .isInstanceOf(OAuthTokenFetchException.class)
                    .hasMessageContaining("Provider unreachable");
        }
    }
}
