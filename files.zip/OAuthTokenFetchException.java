package com.fazil.payment.exception;

public class OAuthTokenFetchException extends RuntimeException {

    public OAuthTokenFetchException(String message) {
        super(message);
    }

    public OAuthTokenFetchException(String message, Throwable cause) {
        super(message, cause);
    }
}
