package com.fazil.payment.token;

import java.time.Instant;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClient;

import com.fazil.payment.config.OAuthProviderProperties;
import com.fazil.payment.exception.OAuthTokenFetchException;

import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.slf4j.Slf4j;

/**
 * Thin HTTP adapter — sole responsibility is fetching a raw token from
 * the OAuth provider's token endpoint.
 *
 * Decorated with @Retry(name = "oauth-fetch") — up to 3 attempts with
 * exponential back-off as configured in application.yml.
 *
 * No caching here. Caching is owned entirely by OAuthTokenCacheService.
 */
@Slf4j
@Component
public class OAuthTokenFetcher {

    private final RestClient            restClient;
    private final OAuthProviderProperties props;

    public OAuthTokenFetcher(
            @Qualifier("oauthRestClient") RestClient restClient,
            OAuthProviderProperties props) {
        this.restClient = restClient;
        this.props      = props;
    }

    /**
     * Performs a client_credentials grant and returns a populated CachedToken.
     * The token's expiresAt is computed from the server-reported expires_in,
     * making it authoritative regardless of our configured TTL.
     *
     * @throws OAuthTokenFetchException on HTTP error or network failure
     */
    @Retry(name = "oauth-fetch")
    public CachedToken fetch() {
        log.info("Fetching new OAuth token from provider");

        var form = new LinkedMultiValueMap<String, String>();
        form.add("grant_type",    "client_credentials");
        form.add("client_id",     props.clientId());
        form.add("client_secret", props.clientSecret());
        form.add("scope",         props.scope());

        try {
            OAuthTokenResponse response = restClient.post()
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body(form)
                    .retrieve()
                    .body(OAuthTokenResponse.class);

            Objects.requireNonNull(response, "Null body from OAuth endpoint");

            Instant expiresAt = Instant.now().plusSeconds(response.expiresIn());
            log.info("OAuth token fetched successfully, expiresIn={}s expiresAt={}",
                    response.expiresIn(), expiresAt);

            return new CachedToken(response.accessToken(), expiresAt);

        } catch (RestClientException ex) {
            log.error("OAuth token fetch failed: {}", ex.getMessage());
            throw new OAuthTokenFetchException("Failed to fetch OAuth token", ex);
        }
    }
}
