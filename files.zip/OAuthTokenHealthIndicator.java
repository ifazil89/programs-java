package com.fazil.payment.health;

import java.time.Instant;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

import com.fazil.payment.cache.OAuthTokenCacheService;
import com.fazil.payment.config.TokenCacheProperties;
import com.fazil.payment.token.CachedToken;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Exposes OAuth token + cache state at GET /actuator/health.
 *
 * Sample response:
 * {
 *   "oauthToken": {
 *     "status": "UP",
 *     "details": {
 *       "tokenPresent":    true,
 *       "tokenExpiry":     "2024-01-15T10:25:00Z",
 *       "remainingMinutes": 22,
 *       "redisCircuit":    "CLOSED",
 *       "localCacheWarm":  true,
 *       "mode":            "REDIS"
 *     }
 *   }
 * }
 */
@Slf4j
@Component("oauthToken")
@RequiredArgsConstructor
public class OAuthTokenHealthIndicator implements HealthIndicator {

    private final OAuthTokenCacheService tokenCacheService;
    private final TokenCacheProperties   cacheProps;

    @Override
    public Health health() {
        try {
            String      token    = tokenCacheService.getToken();
            CachedToken snapshot = tokenCacheService.localCacheSnapshot();
            CircuitBreaker.State cbState = tokenCacheService.redisCircuitState();

            boolean hasToken    = token != null && !token.isBlank();
            boolean localWarm   = snapshot != null &&
                                  !snapshot.isExpiredOrExpiringSoon(cacheProps.refreshBufferMinutes());
            String  mode        = cbState == CircuitBreaker.State.OPEN ? "LOCAL_FALLBACK" : "REDIS";
            Instant expiry      = snapshot != null ? snapshot.expiresAt() : null;
            long    remaining   = snapshot != null
                    ? snapshot.remainingValidity().toMinutes()
                    : -1;

            return (hasToken ? Health.up() : Health.down())
                    .withDetail("tokenPresent",     hasToken)
                    .withDetail("tokenExpiry",      expiry != null ? expiry.toString() : "unknown")
                    .withDetail("remainingMinutes", remaining)
                    .withDetail("redisCircuit",     cbState.name())
                    .withDetail("localCacheWarm",   localWarm)
                    .withDetail("mode",             mode)
                    .build();

        } catch (Exception e) {
            log.error("Health check failed: {}", e.getMessage());
            return Health.down()
                    .withDetail("error",        e.getMessage())
                    .withDetail("redisCircuit", safeCircuitState())
                    .build();
        }
    }

    private String safeCircuitState() {
        try {
            return tokenCacheService.redisCircuitState().name();
        } catch (Exception e) {
            return "UNKNOWN";
        }
    }
}
