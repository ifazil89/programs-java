package com.fazil.payment.token;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Deserialized response from the OAuth provider's token endpoint.
 * Unknown fields are ignored for forward-compatibility with provider changes.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record OAuthTokenResponse(

        @JsonProperty("access_token") String accessToken,
        @JsonProperty("expires_in")   long   expiresIn,     // seconds
        @JsonProperty("token_type")   String tokenType,
        @JsonProperty("scope")        String scope
) {
    /**
     * Compact validation on construction — fails loudly on bad provider responses.
     */
    public OAuthTokenResponse {
        if (accessToken == null || accessToken.isBlank()) {
            throw new IllegalStateException(
                    "OAuth provider returned empty access_token");
        }
        if (expiresIn <= 0) {
            throw new IllegalStateException(
                    "OAuth provider returned invalid expires_in: " + expiresIn);
        }
    }
}
