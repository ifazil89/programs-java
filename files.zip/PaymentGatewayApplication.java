package com.fazil.payment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.fazil.payment.config.OAuthProviderProperties;
import com.fazil.payment.config.TokenCacheProperties;

@SpringBootApplication
@EnableConfigurationProperties({
        OAuthProviderProperties.class,
        TokenCacheProperties.class
})
public class PaymentGatewayApplication {
    public static void main(String[] args) {
        SpringApplication.run(PaymentGatewayApplication.class, args);
    }
}
