package com.fazil.payment.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

/**
 * Binds to cache.oauth-token.* in application.yml.
 * Drives TTL for both Redis L1 and Caffeine L2 independently.
 */
@Validated
@ConfigurationProperties(prefix = "cache.oauth-token")
public record TokenCacheProperties(

        @Min(1) @Max(60) int redisTtlMinutes,
        @Min(1) @Max(60) int caffeineTtlMinutes,
        @Min(1) @Max(10) int refreshBufferMinutes,
        @Min(1) @Max(100) int maxCaffeineSize
) {}
