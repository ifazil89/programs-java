package com.fazil.payment.cache;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fazil.payment.config.TokenCacheProperties;
import com.fazil.payment.token.CachedToken;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Internal ops endpoint — NOT for end-user traffic.
 * Secure this behind an internal network rule or Spring Security admin role.
 *
 * GET  /internal/token/status  — view current token state (no token value exposed)
 * DELETE /internal/token       — force evict both caches (triggers refresh on next call)
 * DELETE /internal/token/all   — evict all entries (use after credential rotation)
 */
@Slf4j
@RestController
@RequestMapping("/internal/token")
@RequiredArgsConstructor
public class TokenDiagnosticController {

    private final OAuthTokenCacheService tokenCacheService;
    private final TokenCacheProperties   cacheProps;

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> status() {
        CachedToken snapshot = tokenCacheService.localCacheSnapshot();

        Map<String, Object> detail = new LinkedHashMap<>();
        detail.put("timestamp",        Instant.now().toString());
        detail.put("redisCircuit",     tokenCacheService.redisCircuitState().name());
        detail.put("localCacheWarm",   snapshot != null &&
                                       !snapshot.isExpiredOrExpiringSoon(cacheProps.refreshBufferMinutes()));
        detail.put("tokenExpiry",      snapshot != null ? snapshot.expiresAt().toString() : "none");
        detail.put("remainingMinutes", snapshot != null ? snapshot.remainingValidity().toMinutes() : -1);
        // accessToken is intentionally NEVER included

        return ResponseEntity.ok(detail);
    }

    @DeleteMapping
    public ResponseEntity<Map<String, String>> evict() {
        log.warn("Manual token eviction triggered via diagnostic endpoint");
        tokenCacheService.evictToken();
        return ResponseEntity.ok(Map.of(
                "status",    "evicted",
                "message",   "Token evicted from Redis L1 and Caffeine L2. Will refresh on next call.",
                "timestamp", Instant.now().toString()
        ));
    }

    @DeleteMapping("/all")
    public ResponseEntity<Map<String, String>> evictAll() {
        log.warn("Full token cache eviction triggered via diagnostic endpoint");
        tokenCacheService.evictAllTokens();
        return ResponseEntity.ok(Map.of(
                "status",    "all-evicted",
                "message",   "All token entries evicted. Will refresh on next call.",
                "timestamp", Instant.now().toString()
        ));
    }
}
